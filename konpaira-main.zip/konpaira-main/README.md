
# konpaira
An online editor to enhance coding, which supports C, C++, Python, Java, Node, Rust and allows you to keep track of all your submissions.

There is an issue with file storage but the whole application runs on local machine.





## Screenshots


![App Screenshot](https://github.com/ankit980533/konpaira/blob/main/screenshots/2022-06-28_12-53.png)
![App Screenshot](https://github.com/ankit980533/konpaira/blob/main/screenshots/2022-06-28_12-53_1.png)
![App Screenshot](https://github.com/ankit980533/konpaira/blob/main/screenshots/2022-06-28_12-54.png)

## Tech Stack

HTML, CSS, JavaScript, EJS, Mongodb, Nodejs, Express




## Deployment

To deploy this project run

```bash
  npm install
  npm start
```

